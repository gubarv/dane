﻿using System;

namespace Labwork_5
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] engAlph ={ { 'A', 'B', 'C', 'D', 'E', },
                              { 'F', 'G', 'H', 'I', 'J', },
                              { 'K', 'L', 'M', 'N', 'O', },
                              { 'P', 'Q', 'R', 'S', 'T', },
                              { 'U', 'V', 'W', 'X', 'Y', },
                              { 'Z', '1', '2', '3', '4', },
                              { '5', ',', '.', '?', '!', }
                             };
            int result = 0;
            if (result<6)
            {
                Console.WriteLine();
            }
            else 
            {
                Console.WriteLine("false");
            }
            Console.WriteLine("Введите английское сообщение буквами для шифровки: ");
            string message = Console.ReadLine();
            string NewMessage = "";
        }
    }
}
