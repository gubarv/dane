﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.CodeDom.Compiler;

namespace Shifr_Cesar
{
    class Cesar : System.Collections.Generic.List<Class1>
    {
        public Cesar()
        {
            this.Add(new Class1("abcdefghiklmnopqrstuvwxyz"));
            this.Add(new Class1("ABCDEFGHIKLMNOPQRSTUVWXYZ"));
            this.Add(new Class1("абвгдеёжзийклмнопрстуфхцчшщъыьэюя"));
            this.Add(new Class1("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"));
            this.Add(new Class1("0123456789"));
            this.Add(new Class1("!\"#%$^&*()+=-_'?.,|/`~№:;@[]{}"));
        }

        public string Codec(string m, int key)
        {
            string res = "", tmp = "";
            for (int i = 0; i < m.Length; i++)
            {
                foreach (Class1 v in this)
                {
                    tmp = v.Repl(m.Substring(i, 1), key);
                    if (tmp != "")
                    {
                        res += tmp;
                        break;
                    }
                }
                if (tmp == "") res += m.Substring(i, 1);
            }
            return res;
        }
    }
}
    class Class1
    {
        string le;

        public Class1(string m)
        {
            le = m;
        }

        public string Repl(string m, int key)
        {
            int pos = le.IndexOf(m);
            if (pos == -1) return "";
            pos = (pos + key) % le.Length;
            if (pos < 0) pos += le.Length;
            return le.Substring(pos, 1);
        }
    }









